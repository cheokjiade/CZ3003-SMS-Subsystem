package test.cz3003.server;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.cz3003.server.LoadBalancer;

public class LoadBalancerTest {

	@Before
	public void setUp() throws Exception {
		LoadBalancer server = new LoadBalancer();
	}

	@Test
	public void testLoadBalancer() {
		fail("Not yet implemented");
	}

	@Test
	public void testSendMessageOut() {
		fail("Not yet implemented");
	}

	@Test
	public void testChooseBestClient() {
		fail("Not yet implemented");
	}

	@Test
	public void testSendMessageToClient() {
		fail("Not yet implemented");
	}

	@Test
	public void testCreateMessageToSMSIntStringStringStringString() {
		fail("Not yet implemented");
	}

	@Test
	public void testCreateMessageToSMSCPUMessage() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdateRecipientList() {
		fail("Not yet implemented");
	}

	@Test
	public void testSendErrorReport() {
		fail("Not yet implemented");
	}

}
